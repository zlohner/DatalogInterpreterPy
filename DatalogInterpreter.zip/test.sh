#bin/bash

function test() {
	inFile="test/Key/Project$1/passoffInput$1$2.txt"
	outFile="test/outputs/out$2.txt"
	expectedFile="test/Key/Project$1/passoffAnswer$1$2.txt"
	diffFile="test/diff.txt"

	echo -ne "\033[38;5;33mTest $2...\033[0m"
	echo -ne "\033[38;5;240m"
	time ./DatalogInterpreter.py "$inFile" $1 > "$outFile"
	echo -ne "\033[0m"
	diff -b "$outFile" "$expectedFile" > "$diffFile"

	diffOutput=""

	while read -r line; do
		diffOutput+="$line"
	done < "$diffFile"

	if [ -z "$diffOutput" ]; then
		echo -e "\033[38;5;36m\033[1mPASSED\033[0m"
	else
		echo -e "\033[38;5;124m\033[1mFAILED\033[0m"
		vimdiff -b "$outFile" "$expectedFile"
		exit 1
	fi

	echo ""
}

declare -a projects=("Scanner" "Parser" "Interpreter" "Rule Evaluation" "Dependency Graph")
function runTests() {
	echo -e "\033[38;5;36mRunning tests for \033[38;5;33m\033[1mProject $1 (${projects[$1-1]})...\033[0m\n"
	fileNums=(0 1 2 3 4 5 6 7 8 9)
	for i in ${fileNums[*]}; do
		test $1 "$i"
	done
	echo ""
}

function testProjects() {
	projectNums=(1 2 3 4 5)
	for i in ${projectNums[*]}; do
		runTests $i
	done
}

echo ""
testProjects

echo -ne "\033[0m"
